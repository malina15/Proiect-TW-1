// Show Menu
const showMenu = (toggleId, navId) => {
    const toggle = document.getElementById(toggleId),
    nav = document.getElementById(navId)

    if (toggle && nav) {
        toggle.addEventListener('click', () => {
            nav.classList.toggle('show')
        })
    }
}
showMenu('nav-toggle', 'nav-menu')

// Remove Menu Mobile
const navLink = document.querySelectorAll('.nav__link')

function linkAction() {
    const navMenu = document.getElementById('nav-menu')
    navMenu.classList.remove('show')
}
navLink.forEach(n => n.addEventListener('click', linkAction))

// Scroll Sections Active Link
const sections = document.querySelectorAll('section[id]')

const scrollActive = () => {
    const scrollDown = window.scrollY

    sections.forEach(current => {
        const sectionHeight = current.offsetHeight,
            sectionTop = current.offsetTop - 58,
            sectionId = current.getAttribute('id'),
            sectionsClass = document.querySelector('.nav__menu a[href*=' + sectionId + ']')

        if (scrollDown > sectionTop && scrollDown <= sectionTop + sectionHeight) {
            sectionsClass.classList.add('active-link')
        } else {
            sectionsClass.classList.remove('active-link')
        }
    })
}
window.addEventListener('scroll', scrollActive)

// Scroll Reveal Animation
const sr = ScrollReveal({
    origin: 'top',
    distance: '60px',
    duration: 2000,
    delay: 200,
    // reset: true // Animation repeat
})

sr.reveal('.home__data, .about__img, .skills__subtitle, .skills__text', {})
sr.reveal('.home__img, .about__subtitle, .about__text, .skills__img', { delay: 400 })
sr.reveal('.home__social-icon', { interval: 200 })
sr.reveal('.skills__data, .work__img, .contact__input', { interval: 200 })

// Smooth Scroll
const links = document.querySelectorAll('.nav__link')

for (const link of links) {
    link.addEventListener('click', clickHandler)
}

function clickHandler(e) {
    e.preventDefault()
    const href = this.getAttribute('href')
    const offsetTop = document.querySelector(href).offsetTop

    scroll({
        top: offsetTop,
        behavior: 'smooth'
    })
}

// Back to Top Button
const backToTopButton = document.createElement('button')
backToTopButton.innerHTML = '↑'
backToTopButton.classList.add('back-to-top')
document.body.appendChild(backToTopButton)

backToTopButton.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    })
})

const toggleBackToTopButton = () => {
    if (window.scrollY > 300) {
        backToTopButton.classList.add('show')
    } else {
        backToTopButton.classList.remove('show')
    }
}
window.addEventListener('scroll', toggleBackToTopButton)

// Light/Dark Mode Toggle
const themeToggleButton = document.createElement('button')
themeToggleButton.innerHTML = '🌙'
themeToggleButton.classList.add('theme-toggle')
document.body.appendChild(themeToggleButton)

themeToggleButton.addEventListener('click', () => {
    document.body.classList.toggle('dark-theme')
    themeToggleButton.innerHTML = document.body.classList.contains('dark-theme') ? '☀️' : '🌙'
})

// Dark theme styles
const style = document.createElement('style')
style.innerHTML = `
    .dark-theme {
        background-color: #222;
        color: #ddd;
    }
    .dark-theme .nav__link {
        color: #ddd;
    }
    .dark-theme .nav__link.active-link {
        color: #fff;
    }
    .dark-theme .skills__bar::before {
        background: #444;
    }
    .theme-toggle {
        position: fixed;
        bottom: 1rem;
        right: 1rem;
        background: #222;
        color: #fff;
        border: none;
        padding: 0.5rem;
        border-radius: 50%;
        cursor: pointer;
        font-size: 1.5rem;
        box-shadow: 0 0 10px rgba(0,0,0,0.5);
    }
    .back-to-top {
        position: fixed;
        bottom: 1rem;
        right: 1rem;
        display: none;
        background: #000;
        color: #fff;
        border: none;
        padding: 0.5rem;
        border-radius: 50%;
        cursor: pointer;
        font-size: 1.5rem;
        box-shadow: 0 0 10px rgba(0,0,0,0.5);
    }
    .back-to-top.show {
        display: block;
    }
`
document.head.appendChild(style)
